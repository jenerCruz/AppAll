declare function isElectron (): boolean
export = isElectron
