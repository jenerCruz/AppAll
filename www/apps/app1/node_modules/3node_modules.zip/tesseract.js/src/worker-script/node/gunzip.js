module.exports = require('zlib').gunzipSync;
