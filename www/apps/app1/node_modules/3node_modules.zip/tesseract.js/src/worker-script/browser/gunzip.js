module.exports = require('zlibjs').gunzipSync;
